"""
File: christlike_attributes_activity.py
Author: Jaden Mounteer

This file creates the Christlike_attributes_activity class which models the christlike attributes activity in PMG.
"""

class Christlike_attributes_activity:
    """ This class doesn't initiate anything. """
    def start_activity(self):
       """  This function begins the activity and shows the instructions."""
       #Displays the title of the activity
       print("__________________________________________________________________________________________________________________________________________________")
       print()
       print("                                                          ATTRIBUTE ACTIVITY")
       print("__________________________________________________________________________________________________________________________________________________")


       #Shows the instructions
       print()
       print(" Read each item below carefully. Decide how true that statement is about you, and choose the most appropriate response from the response key.")
       print("Write your response to each item in your study journal. Spiritual growth is a gradual process, and no one is perfect, so you should expect to rate")
       print("yourself better on some items than on others.")

       #Shows the response key.
       print("__________________________________________________________________________________________________________________________________________________")
       print()
       print("                          Response Key 1 = never 2 = sometimes 3 = often 4 = almost always 5 = always")
       print("__________________________________________________________________________________________________________________________________________________")
    
    def faith(self):
        """ This function prompts the user with the faith questions. Returns the total number of points. """
        #Displays the word Faith.
        print()
        print("Faith")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I believe in Christ and accept Him as my savior. (2 Nephi 25:29)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I feel confident that God loves me. (1 Nephi 11:17)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I trust the Savior enough to accept His will and do whatever He asks. (1 Nephi 3:7)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I firmly believe that through the Atonement of Jesus Christ I can be forgiven of all my sins. (Enos 1:5–8)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I have enough faith in Christ to obtain answers to my prayers. (Mosiah 27:14)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 6
        while looping == True:
            try:
                print("6. I think about the Savior during the day and remember what He has done for me. (D&C 20:77, 79)")
                question6 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question6 > 5 or question6 < 1:
                print()
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 7
        while looping == True:
            try:
                print("7. I have the faith necessary to help make good things happen in my life or the lives of others. (Ether 12:12)")
                question7 = int(input("Type your response here: "))
                print()
            except ValueError:
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question7 > 5 or question7 < 1:
                print()
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 8
        while looping == True:
            try:
                print("8. I know by the power of the Holy Ghost that the Book of Mormon is true. (Moroni 10:3–5)")
                question8 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question8 > 5 or question8 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 9
        while looping == True:
            try:
                print("9. I have enough faith in Christ to accomplish anything He wants me to do—even miracles if necessary. (Moroni 7:33)")
                question9 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question9 > 5 or question9 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5 + question6 + question7 + question8 + question9
    
    def hope(self):
        """ This function prompts the user with the hope questions and returns the total score. """
        #Displays the word Hope.
        print()
        print("Hope")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. One of my greatest desires is to inherit eternal life in the celestial kingdom of God. (Moroni 7:41)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I am confident that I will have a happy and successful life/mission. (D&C 31:3–5)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I feel peaceful and optimistic about the future. (D&C 59:23)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I firmly believe that someday I will dwell with God and become like Him. (Ether 12:4)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4

    def charity_and_love(self):
        """ This function prompts the user with the charity and love questions and returns the total score. """
        #Displays the phrase charity and love.
        print()
        print("Charity and Love")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I feel a sincere desire for the eternal welfare and happiness of other people. (Mosiah 28:3)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. When I pray, I ask for charity—the pure love of Christ. (Moroni 7:47–48)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I try to understand others’ feelings and see their point of view. (Jude 1:22)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I forgive others who have offended or wronged me. (Ephesians 4:32)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I try to help others when they are struggling or discouraged. (Mosiah 18:9)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 6
        while looping == True:
            try:
                print("6. When appropriate, I tell others that I love them and care about them. (Luke 7:12–15)")
                question6 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question6 > 5 or question6 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 7
        while looping == True:
            try:
                print("7. I look for opportunities to serve other people. (Mosiah 2:17)")
                question7 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question7 > 5 or question7 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 8
        while looping == True:
            try:
                print("8. I say positive things about others. (D&C 42:27)")
                question8 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question8 > 5 or question8 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 9
        while looping == True:
            try:
                print("9. I am kind and patient with others, even when they are hard to get along with. (Moroni 7:45)")
                question9 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question9 > 5 or question9 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 10
        while looping == True:
            try:
                print("10.  I find joy in others’ achievements. (Alma 17:2–4)")
                question10 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question10 > 5 or question10 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5 + question6 + question7 + question8 + question9 + question10
    
    def virtue(self):
        """ This function prompts the user with the virtue questions and returns the total score. """
        #Displays the word virtue.
        print()
        print("Virtue")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I am clean and pure in heart. (Psalm 24:3–4)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I have no desire to do evil but to do good. (Mosiah 5:2)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I am dependable—I do what I say I will do. (Alma 53:20)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I focus on righteous, uplifting thoughts and put unwholesome thoughts out of my mind. (D&C 121:45)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I repent of my sins and strive to overcome my weaknesses. (D&C 49:26–28)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 6
        while looping == True:
            try:
                print("6. I feel the influence of the Holy Ghost in my life. (D&C 11:12–13) ")
                question6 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question6 > 5 or question6 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
            
        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5 + question6
    
    def knowledge(self):
        """ This function prompts the user with the knowledge questions and returns the total score. """
        #Displays the word knowledge.
        print()
        print("Knowledge")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I feel confident in my understanding of gospel doctrines and principles. (Ether 3:19–20)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I study the scriptures daily. (John 5:39)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I earnestly seek to understand the truth and find answers to my questions. (D&C 6:7)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I receive knowledge and guidance through the Spirit. (1 Nephi 4:6)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I love and cherish the doctrines and principles of the gospel. (2 Nephi 4:15)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break

        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5
    
    def patience(self):
        """ This function prompts the user with the patience questions and returns the total score. """
        #Displays the word knowledge.
        print()
        print("Patience")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I wait patiently for the blessings and promises of the Lord to be fulfilled. (2 Nephi 10:17)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I am able to wait for things without getting upset or frustrated. (Romans 8:25)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I am patient and long-suffering with the challenges of being a missionary. (Alma 17:11)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I am patient with the faults and weaknesses of others. (Romans 15:1)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I am patient with myself and rely on the Lord as I work to overcome my weaknesses. (Ether 12:27)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 6
        while looping == True:
            try:
                print("5. I face adversity and afflictions calmly and hopefully. (Alma 34:40–41)")
                question6 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question6 > 5 or question6 < 1:
                print("Please enter a number from 1-5.")
            else:
                break

        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5 + question6
    
    def humility(self):
        """ This function prompts the user with the humility questions and returns the total score. """
        #Displays the word humility.
        print()
        print("Humility")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I am meek and lowly in heart. (Matthew 11:29)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I rely on the Lord for help. (Alma 26:12)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I am sincerely grateful for the blessings I have received from the Lord. (Alma 7:23)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. My prayers are earnest and sincere. (Enos 1:4)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I appreciate direction from my leaders or teachers. (2 Nephi 9:28)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 6
        while looping == True:
            try:
                print("5. I strive to be submissive to the Lord’s will, whatever it may be. (Mosiah 24:15)")
                question6 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question6 > 5 or question6 < 1:
                print("Please enter a number from 1-5.")
            else:
                break

        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5 + question6
    
    def diligence(self):
        """ This function prompts the user with the diligence questions and returns the total score. """
        #Displays the word humility.
        print()
        print("Diligence")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. I work effectively, even when I’m not under pressure or close supervision. (D&C 58:26–27)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I focus my efforts on the most important things. (Matthew 23:23)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I have a personal prayer at least twice a day. (Alma 34:18–27)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I focus my thoughts on my calling as a missionary. (D&C 4:2, 5)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 5
        while looping == True:
            try:
                print("5. I set goals and plan regularly. (D&C 88:119)")
                question5 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question5 > 5 or question5 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 6
        while looping == True:
            try:
                print("5. I work hard until the job is completed successfully. (D&C 10:4)")
                question6 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question6 > 5 or question6 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 7
        while looping == True:
            try:
                print("5. I find joy and satisfaction in my work. (Alma 36:24–25)")
                question7 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question7 > 5 or question7 < 1:
                print("Please enter a number from 1-5.")
            else:
                break

        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4 + question5 + question6 + question7
    
    def obedience(self):
        """ This function prompts the user with the obedience questions and returns the total score. """
        #Displays the word humility.
        print()
        print("Obedience")
        #prompts the user with the questions.
        looping = True
        
        #Question 1
        while looping == True:
            try:
                print("1. When I pray, I ask for strength to resist temptation and to do what is right. (3 Nephi 18:15)")
                question1 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question1 > 5 or question1 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 2
        while looping == True:
            try:
                print("2. I keep the required commandments to be worthy of a temple recommend. (D&C 97:8)")
                question2 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question2 > 5 or question2 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 3
        while looping == True:
            try:
                print("3. I willingly obey the mission rules and follow the counsel of my leaders. (Hebrews 13:17)")
                question3 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question3 > 5 or question3 < 1:
                print("Please enter a number from 1-5.")
            else:
                break
        
        #Question 4
        while looping == True:
            try:
                print("4. I strive to live in accordance with the laws and principles of the gospel. (D&C 41:5)")
                question4 = int(input("Type your response here: "))
                print()
            except ValueError:
                print()
                print("Please type a number from 1-5")
                continue
            #tests to see if the user entered a valid number
            if question4 > 5 or question4 < 1:
                print("Please enter a number from 1-5.")
            else:
                break

        #Returns the total points accumulated.
        return question1 + question2 + question3 + question4
