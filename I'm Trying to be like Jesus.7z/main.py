"""
File: main.py
Author: Jaden Mounteer

This file models the main menu of the program, I Want to Be Like Jesus.
It displays the main menu and the options available to the user. For now, the user will be prompted to begin 
the Christlike attributes activity.
"""

#Imports the christlike attributes activity class.
from christlike_attributes_activity import Christlike_attributes_activity

def main():
    #Displays the main menu and title.
    print("__________________________________________________________________________________________________________________________________________________")
    print()
    print("                                                       I'M TRYING TO BE LIKE JESUS")
    print("__________________________________________________________________________________________________________________________________________________")

    #Prompts the user to begin the Christlike Attributes activity.
    print()
    print(input("Press ENTER to begin the Christlike Attributes activity..."))

    #Creates an object of the Christlike attributes activity.
    christlike_attributes_activity = Christlike_attributes_activity()

    #Calls the start_activity function.
    christlike_attributes_activity.start_activity()

    #calls the faith function and stores the value in the faith_score variable. Also calculates the total points possible for faith. Calculates the percentage as well.
    faith_score = christlike_attributes_activity.faith()
    total_faith_points_possible = 45
    faith_percentage = "{:.0%}".format(faith_score / total_faith_points_possible) # uses str. format() to format the number as a percentage.

    #Calls the hope function and organizes the score and percent into variables
    hope_score = christlike_attributes_activity.hope()
    total_hope_points_possible = 20
    hope_percentage = "{:.0%}".format(hope_score / total_hope_points_possible)

    #Calls the charity and love function and organizes the score and percent into variables
    charity_and_love_score = christlike_attributes_activity.charity_and_love()
    total_charity_and_love_points_possible = 50
    charity_and_love_percentage = "{:.0%}".format(charity_and_love_score / total_charity_and_love_points_possible)

    #Calls the virtue function and organizes the score and percent into variables
    virtue_score = christlike_attributes_activity.virtue()
    total_virtue_points_possible = 30
    virtue_percentage = "{:.0%}".format(virtue_score / total_virtue_points_possible)

    #Calls the knowledge function and organizes the score and percent into variables
    knowledge_score = christlike_attributes_activity.knowledge()
    total_knowledge_points_possible = 25
    knowledge_percentage = "{:.0%}".format(knowledge_score / total_knowledge_points_possible)

    #Calls the patience function and organizes the score and percent into variables
    patience_score = christlike_attributes_activity.patience()
    total_patience_points_possible = 30
    patience_percentage = "{:.0%}".format(patience_score / total_patience_points_possible)

    #Calls the humility function and organizes the score and percent into variables
    humility_score = christlike_attributes_activity.humility()
    total_humility_points_possible = 30
    humility_percentage = "{:.0%}".format(humility_score / total_humility_points_possible)

    #Calls the diligence function and organizes the score and percent into variables
    diligence_score = christlike_attributes_activity.diligence()
    total_diligence_points_possible = 35
    diligence_percentage = "{:.0%}".format(diligence_score / total_diligence_points_possible)

    #Calls the obedience function and organizes the score and percent into variables
    obedience_score = christlike_attributes_activity.obedience()
    total_obedience_points_possible = 20
    obedience_percentage = "{:.0%}".format(obedience_score / total_obedience_points_possible)

    #Displays the results to the user.
    print("__________________________________________________________________________________________________________________________________________________")
    print()
    print("                                                                 RESULTS")
    print("__________________________________________________________________________________________________________________________________________________")
    print()
    print("Faith")
    print("Score: " + str(faith_score) + "/" + str(total_faith_points_possible))
    print("Percentage: " + str(faith_percentage))
    print()
    print("Hope")
    print("Score: " + str(hope_score) + "/" + str(total_hope_points_possible))
    print("Percentage: " + str(hope_percentage))
    print()
    print("Charity and Love")
    print("Score: " + str(charity_and_love_score) + "/" + str(total_charity_and_love_points_possible))
    print("Percentage: " + str(charity_and_love_percentage))
    print()
    print("Virtue")
    print("Score: " + str(virtue_score) + "/" + str(total_virtue_points_possible))
    print("Percentage: " + str(virtue_percentage))
    print()
    print("Knowledge")
    print("Score: " + str(knowledge_score) + "/" + str(total_knowledge_points_possible))
    print("Percentage: " + str(knowledge_percentage))
    print()
    print("Patience")
    print("Score: " + str(patience_score) + "/" + str(total_patience_points_possible))
    print("Percentage: " + str(patience_percentage))
    print()
    print("Humility")
    print("Score: " + str(humility_score) + "/" + str(total_humility_points_possible))
    print("Percentage: " + str(humility_percentage))
    print()
    print("Diligence")
    print("Score: " + str(diligence_score) + "/" + str(total_diligence_points_possible))
    print("Percentage: " + str(diligence_percentage))
    print()
    print("Obedience")
    print("Score: " + str(obedience_score) + "/" + str(total_obedience_points_possible))
    print("Percentage: " + str(obedience_percentage))
    print()



#Calls the main function.
if __name__ == '__main__':
    main()