"""
File: main.py
Author: Jaden Mounteer

This file models the main menu of the program, I Want to Be Like Jesus.
It displays the main menu and the options available to the user. For now, the user will be prompted to begin 
the Christlike attributes activity.
"""

#Imports the christlike attributes activity class.
from christlike_attributes_activity import Christlike_attributes_activity

def main():
    #Displays the main menu and title.
    print("__________________________________________________________________________________________________________________________________________________")
    print()
    print("                                                       I'M TRYING TO BE LIKE JESUS")
    print("__________________________________________________________________________________________________________________________________________________")

    #Prompts the user to begin the Christlike Attributes activity.
    print()
    print(input("Press ENTER to begin the Christlike Attributes activity..."))

    #Creates an object of the Christlike attributes activity.
    christlike_attributes_activity = Christlike_attributes_activity()

    #Calls the start_activity function.
    christlike_attributes_activity.start_activity()

    #calls the faith function and stores the value in the faith_score variable. Also calculates the total points possible for faith. Calculates the percentage as well.
    faith_score = christlike_attributes_activity.faith()
    total_faith_points_possible = 45
    faith_percentage = "{:.0%}".format(faith_score / total_faith_points_possible) # uses str. format() to format the number as a percentage.

    #Calls the hope function and organizes the score and percent into variables
    hope_score = christlike_attributes_activity.hope()
    total_hope_points_possible = 20
    hope_percentage = "{:.0%}".format(hope_score / total_hope_points_possible)

    #Calls the charity and love function and organizes the score and percent into variables
    charity_and_love_score = christlike_attributes_activity.charity_and_love()
    total_charity_and_love_points_possible = 50
    charity_and_love_percentage = "{:.0%}".format(charity_and_love_score / total_charity_and_love_points_possible)

    #Displays the results to the user.
    print("__________________________________________________________________________________________________________________________________________________")
    print()
    print("                                                                 RESULTS")
    print("__________________________________________________________________________________________________________________________________________________")
    print()
    print("Faith")
    print("Score: " + str(faith_score) + "/" + str(total_faith_points_possible))
    print("Percentage: " + str(faith_percentage))
    print()
    print("Hope")
    print("Score: " + str(hope_score) + "/" + str(total_hope_points_possible))
    print("Percentage: " + str(hope_percentage))
    print()
    print("Charity and Love")
    print("Score: " + str(hope_score) + "/" + str(total_charity_and_love_points_possible))
    print("Percentage: " + str(charity_and_love_percentage))
    print()



#Calls the main function.
if __name__ == '__main__':
    main()